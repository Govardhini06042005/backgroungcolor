const express = require('express');
const mongoose = require('mongoose');
const cors = require("cors");
const UserModel = require('./models/User');
const MedicationModel = require('./models/Medication');
const nodemailer = require('nodemailer');
const nodeCron = require('node-cron');
const moment = require('moment');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(cors());

// Connect to MongoDB
mongoose.connect("mongodb://127.0.0.1:27017/login")
    .then(() => console.log("MongoDB connected"))
    .catch(err => console.error("MongoDB connection error:", err));

// Login endpoint
app.post("/login", (req, res) => {
    const { email, password } = req.body;
    UserModel.findOne({ email })
        .then(user => {
            if (user) {
                if (user.password === password) {
                    res.json("Success");
                } else {
                    res.status(401).json("Incorrect password");
                }
            } else {
                res.status(404).json("No record exists");
            }
        })
        .catch(err => res.status(500).json({ error: "Server error" }));
});

// Signup endpoint
app.post('/signup', (req, res) => {
    UserModel.create(req.body)
        .then(user => res.status(201).json(user))
        .catch(err => res.status(400).json({ error: err.message }));
});

// Medication endpoint
app.post('/medications', async (req, res) => {
    try {
        const medication = await MedicationModel.create(req.body);
        res.status(201).json(medication);
    } catch (err) {
        console.error("Error creating medication:", err);
        res.status(400).json({ error: "Submission failed. Please try again later." });
    }
});

// Configure email transporter
const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: {
        user: process.env.GMAIL,
        pass: process.env.PASS
    }
});

// Scheduled task to send reminders
nodeCron.schedule('0 * * * *', async () => { // Runs every hour
    console.log(`[${new Date().toISOString()}] Scheduled task running...`);

    try {
        const now = new Date();
        const currentTime = now.toTimeString().slice(0, 5); // HH:MM
        const currentDay = moment(now).format('dddd');
        const currentDate = moment(now).format('YYYY-MM-DD');

        // Fetch medications matching the current time and day
        const medications = await MedicationModel.find({
            "medications.time": currentTime,
            "medications.days": currentDay
        });

        for (const user of medications) {
            for (const med of user.medications) {
                if (med.time === currentTime && med.days.includes(currentDay)) {
                    // Send medication reminder email
                    const mailOptions = {
                        from: process.env.GMAIL,
                        to: user.email,
                        subject: 'Medication Reminder',
                        text: `Hi ${user.name}, it's time to take your medication: ${med.name}.`
                    };

                    try {
                        await transporter.sendMail(mailOptions);
                        console.log(`Reminder email sent to ${user.email} for medication: ${med.name}`);
                    } catch (emailError) {
                        console.error(`Failed to send email to ${user.email}:`, emailError);
                    }
                }
            }
        }

        // Fetch medications for refill reminders
        const medicationsForRefill = await MedicationModel.find({
            "medications.refillDate": currentDate,
            "medications.refillReminderSent": false
        });

        for (const user of medicationsForRefill) {
            for (const med of user.medications) {
                if (moment(med.refillDate).format('YYYY-MM-DD') === currentDate) {
                    // Send refill reminder email
                    const mailOptions = {
                        from: process.env.GMAIL,
                        to: user.email,
                        subject: 'Medication Refill Reminder',
                        text: `Hi ${user.name}, please refill your medication: ${med.name}.`
                    };

                    try {
                        await transporter.sendMail(mailOptions);
                        console.log(`Refill email sent to ${user.email} for medication: ${med.name}`);

                        // Mark reminder as sent
                        await MedicationModel.updateOne(
                            { _id: user._id, "medications._id": med._id },
                            { $set: { "medications.$.refillReminderSent": true } }
                        );
                    } catch (emailError) {
                        console.error(`Failed to send refill email to ${user.email}:`, emailError);
                    }
                }
            }
        }
    } catch (error) {
        console.error("Error in scheduled task:", error);
    }
});

// Start the server
app.listen(3001, () => {
    console.log("Server is running on port 3001");
});
